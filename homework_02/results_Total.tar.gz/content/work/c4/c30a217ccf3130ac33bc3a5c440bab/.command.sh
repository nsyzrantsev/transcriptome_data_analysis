#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410610_1.fastq SRR6410610_2.fastq
