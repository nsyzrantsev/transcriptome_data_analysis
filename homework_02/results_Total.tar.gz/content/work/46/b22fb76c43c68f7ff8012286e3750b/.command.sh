#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410609_1.fastq SRR6410609_2.fastq
