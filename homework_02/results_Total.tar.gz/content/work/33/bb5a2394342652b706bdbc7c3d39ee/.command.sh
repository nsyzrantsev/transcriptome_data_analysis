#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410617_1.fastq SRR6410617_2.fastq
