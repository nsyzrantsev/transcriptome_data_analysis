#!/bin/bash -ue
mkdir SRR6410608
/content/kallisto/build/src/kallisto quant -i /content/index/Homo_sapiens_GRCh38_transcriptome.idx -o SRR6410608 SRR6410607_1.fastq SRR6410607_2.fastq
