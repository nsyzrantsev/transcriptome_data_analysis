#!/bin/bash -ue
mkdir SRR6410615
/content/kallisto/build/src/kallisto quant -i /content/index/Homo_sapiens_GRCh38_transcriptome.idx -o SRR6410615 SRR6410616_1.fastq SRR6410616_2.fastq
