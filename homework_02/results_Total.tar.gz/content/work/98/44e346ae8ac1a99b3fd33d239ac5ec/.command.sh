#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410608_1.fastq SRR6410608_2.fastq
