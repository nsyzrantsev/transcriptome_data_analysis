#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410616_1.fastq SRR6410616_2.fastq
