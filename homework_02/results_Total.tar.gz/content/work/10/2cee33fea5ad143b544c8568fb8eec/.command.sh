#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410618_1.fastq SRR6410618_2.fastq
