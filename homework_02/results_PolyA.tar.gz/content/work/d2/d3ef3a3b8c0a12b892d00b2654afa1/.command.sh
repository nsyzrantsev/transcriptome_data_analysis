#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410612_1.fastq SRR6410612_2.fastq
