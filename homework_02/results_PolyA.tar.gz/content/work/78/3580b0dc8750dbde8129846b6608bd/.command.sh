#!/bin/bash -ue
mkdir SRR6410612
/content/kallisto/build/src/kallisto quant -i /content/index/Homo_sapiens_GRCh38_transcriptome.idx -o SRR6410612 SRR6410611_1.fastq SRR6410611_2.fastq
