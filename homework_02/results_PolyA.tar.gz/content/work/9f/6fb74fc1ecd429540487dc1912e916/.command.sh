#!/bin/bash -ue
mkdir SRR6410604
/content/kallisto/build/src/kallisto quant -i /content/index/Homo_sapiens_GRCh38_transcriptome.idx -o SRR6410604 SRR6410603_1.fastq SRR6410603_2.fastq
