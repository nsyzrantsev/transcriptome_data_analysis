#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410603_1.fastq SRR6410603_2.fastq
