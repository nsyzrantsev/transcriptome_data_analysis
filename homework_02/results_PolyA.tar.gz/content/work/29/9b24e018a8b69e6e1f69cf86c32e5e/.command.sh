#!/bin/bash -ue
mkdir SRR6410605
/content/kallisto/build/src/kallisto quant -i /content/index/Homo_sapiens_GRCh38_transcriptome.idx -o SRR6410605 SRR6410606_1.fastq SRR6410606_2.fastq
