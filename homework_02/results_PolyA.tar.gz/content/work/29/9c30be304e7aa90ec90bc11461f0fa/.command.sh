#!/bin/bash -ue
mkdir fastqc
/content/FastQC/fastqc -o fastqc SRR6410605_1.fastq SRR6410605_2.fastq
