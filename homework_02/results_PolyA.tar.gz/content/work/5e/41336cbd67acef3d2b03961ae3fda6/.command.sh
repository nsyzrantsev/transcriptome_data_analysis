#!/bin/bash -ue
/content/sratoolkit.3.0.0-ubuntu64/bin/fasterq-dump SRR6410611 -O SRR6410611/
