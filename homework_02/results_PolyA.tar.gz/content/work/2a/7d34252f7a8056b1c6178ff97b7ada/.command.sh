#!/bin/bash -ue
/content/sratoolkit.3.0.0-ubuntu64/bin/fasterq-dump SRR6410605 -O SRR6410605/
